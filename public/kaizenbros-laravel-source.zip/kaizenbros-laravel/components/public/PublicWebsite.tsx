'use client';

import React, { useState } from 'react';
import { 
  Building2, 
  ShieldCheck, 
  PhoneCall, 
  Clock, 
  MapPin, 
  Heart, 
  Droplet, 
  CheckCircle2, 
  ChevronRight, 
  User, 
  Lock, 
  Calendar, 
  Sparkles, 
  Activity, 
  Mail, 
  MessageCircle,
  HelpCircle,
  Stethoscope
} from 'lucide-react';
import { VERIFIED_CENTRE_INFO } from '@/lib/mock-data';

interface PublicWebsiteProps {
  onLoginAsPatient: () => void;
  onLoginAsNurse: () => void;
  onLoginAsAdmin: () => void;
}

export function PublicWebsite({
  onLoginAsPatient,
  onLoginAsNurse,
  onLoginAsAdmin
}: PublicWebsiteProps) {
  const [activeSection, setActiveSection] = useState<'home' | 'about' | 'services' | 'info' | 'centre' | 'contact'>('home');
  const [showLoginModal, setShowLoginModal] = useState<'patient' | 'staff' | null>(null);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950 py-16 sm:py-24 border-b border-slate-800">
        <div className="absolute right-0 top-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="max-w-7xl mx-auto px-4 sm:px-8 relative z-10">
          <div className="max-w-3xl space-y-6">
            <div className="inline-flex items-center space-x-2 bg-emerald-950/80 border border-emerald-700/60 px-3.5 py-1.5 rounded-full text-xs font-bold text-emerald-400">
              <ShieldCheck className="w-4 h-4" />
              <span>Pusat Hemodialisis Berdaftar KKM ({VERIFIED_CENTRE_INFO.kkm_license})</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-tight">
              Pusat Dialisis <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-teal-300 to-emerald-400">KaizenBros</span>
            </h1>

            <p className="text-lg sm:text-xl text-slate-300 leading-relaxed font-normal">
              {VERIFIED_CENTRE_INFO.slogan}. Menyediakan rawatan hemodialisis moden berstandard antarabangsa di Semenyih, dipantau oleh Pakar Nefrologi dan jururawat terlatih.
            </p>

            {/* Quick Action CTA Buttons */}
            <div className="flex flex-wrap items-center gap-4 pt-4">
              <button
                onClick={() => setShowLoginModal('patient')}
                className="min-h-[52px] px-6 py-3 bg-emerald-500 hover:bg-emerald-400 active:bg-emerald-600 text-slate-950 font-black text-base rounded-2xl transition-all shadow-xl shadow-emerald-950/50 flex items-center space-x-2 cursor-pointer"
              >
                <User className="w-5 h-5" />
                <span>LOG MASUK PESAKIT</span>
                <ChevronRight className="w-5 h-5" />
              </button>

              <button
                onClick={() => setShowLoginModal('staff')}
                className="min-h-[52px] px-6 py-3 bg-slate-800 hover:bg-slate-750 active:bg-slate-700 text-white font-bold text-base rounded-2xl transition-all border border-slate-700 flex items-center space-x-2 cursor-pointer"
              >
                <Lock className="w-4 h-4 text-cyan-400" />
                <span>PORTAL STAF / JURURAWAT</span>
              </button>

              <a
                href={`https://wa.me/${VERIFIED_CENTRE_INFO.whatsapp_number}?text=Salam%20KaizenBros,%20saya%20ingin%20membuat%20pertanyaan%20kemasukan%20rawatan%20dialisis.`}
                target="_blank"
                rel="noreferrer"
                className="min-h-[52px] px-5 py-3 bg-teal-950/80 hover:bg-teal-900 border border-teal-700 text-teal-300 font-bold text-sm rounded-2xl flex items-center space-x-2"
              >
                <MessageCircle className="w-4 h-4 text-teal-400" />
                <span>WhatsApp KaizenBros</span>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Highlights Grid */}
      <section className="py-16 bg-slate-900/60 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 space-y-12">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <h2 className="text-3xl font-black text-white">Kemudahan Rawatan Berkualiti Tinggi</h2>
            <p className="text-slate-400 text-sm">Direka khas untuk keselesaan dan keselamatan optimum pesakit buah pinggang</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-3">
              <div className="w-12 h-12 rounded-xl bg-cyan-950 border border-cyan-800 flex items-center justify-center text-cyan-400">
                <Heart className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white">12 Mesin Dialisis Fresenius</h3>
              <p className="text-slate-400 text-sm leading-relaxed">
                Dilengkapi mesin berprestasi tinggi Fresenius 4008S NG dan 5008S CorDiax yang menyokong terapi Online HDF untuk penapisan toksin uremik yang lebih bersih.
              </p>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-3">
              <div className="w-12 h-12 rounded-xl bg-teal-950 border border-teal-800 flex items-center justify-center text-teal-400">
                <Droplet className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white">Air RO Double Pass AAMI/ISO</h3>
              <p className="text-slate-400 text-sm leading-relaxed">
                Sistem rawatan air Reverse Osmosis (RO) berganda mematuhi standard piawaian ketat antarabangsa AAMI/ISO 23500 bagi memastikan ketulenan air ultra-murni.
              </p>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-3">
              <div className="w-12 h-12 rounded-xl bg-emerald-950 border border-emerald-800 flex items-center justify-center text-emerald-400">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white">Panel Penaja Diiktiraf</h3>
              <p className="text-slate-400 text-sm leading-relaxed">
                Menerima penajaan penuh PERKESO / SOCSO, JPA/KWAP, Lembaga Zakat Selangor (LZS), Baitulmal MAIWP, Yayasan Buah Pinggang Kebangsaan (NKF) & Insurans.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Verified Centre Details Section */}
      <section className="py-16 bg-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 space-y-8">
          <div className="max-w-3xl space-y-2">
            <span className="text-xs uppercase font-extrabold text-cyan-400 tracking-wider">
              MAKLUMAT PUSAT DIALISIS KAIZENBROS
            </span>
            <h2 className="text-3xl font-black text-white">Lokasi & Waktu Operasi</h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Address and Contact Card */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6">
              <div className="flex items-start space-x-4">
                <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-cyan-400 flex-shrink-0 mt-1">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-white text-base">Alamat Pusat:</h4>
                  <p className="text-slate-300 text-sm mt-1">{VERIFIED_CENTRE_INFO.address}</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-cyan-400 flex-shrink-0 mt-1">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-white text-base">Waktu Operasi Sesi:</h4>
                  <p className="text-slate-300 text-sm mt-1">Isnin - Sabtu: 6:00 Pagi - 6:00 Petang (3 Sesi: Pagi, Tengahari, Petang)</p>
                  <p className="text-slate-500 text-xs mt-0.5">Ahad: Tutup (Kecemasan On-Call Sahaja)</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-rose-400 flex-shrink-0 mt-1">
                  <PhoneCall className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-white text-base">Perhubungan & Kecemasan:</h4>
                  <p className="text-slate-300 text-sm mt-1">Telefon Pejabat: {VERIFIED_CENTRE_INFO.phone_main}</p>
                  <p className="text-rose-400 font-bold text-sm">Talian Kecemasan 24 Jam: {VERIFIED_CENTRE_INFO.hotline_24h}</p>
                </div>
              </div>
            </div>

            {/* Panels List Card */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-4">
              <h4 className="font-bold text-white text-lg flex items-center">
                <ShieldCheck className="w-5 h-5 mr-2 text-emerald-400" />
                Senarai Panel Penajaan
              </h4>
              <p className="text-xs text-slate-400">
                Pusat Dialisis KaizenBros bekerjasama rapat dengan agensi kerajaan dan institusi penaja untuk meringankan kos rawatan pesakit.
              </p>
              <div className="space-y-2.5 pt-2">
                {VERIFIED_CENTRE_INFO.panels.map((p, idx) => (
                  <div key={idx} className="flex items-center space-x-3 bg-slate-950 p-3 rounded-xl border border-slate-800">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    <span className="text-sm font-semibold text-slate-200">{p}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-slate-800 py-8 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 space-y-2">
          <p>© 2026 Pusat Dialisis KaizenBros (KaizenBros Dialysis Centre). No. Pendaftaran KKM: {VERIFIED_CENTRE_INFO.kkm_license}</p>
          <p>Hakcipta Terpelihara. Aplikasi Pengurusan Klinikal Berasaskan Laravel 13 & MySQL 8.x.</p>
        </div>
      </footer>

      {/* LOGIN MODAL */}
      {showLoginModal && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border-2 border-slate-700 rounded-3xl max-w-md w-full p-6 sm:p-7 text-white space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-xl font-black text-white">
                {showLoginModal === 'patient' ? 'Log Masuk Portal Pesakit' : 'Log Masuk Portal Staf / Pentadbir'}
              </h3>
              <button 
                onClick={() => setShowLoginModal(null)}
                className="w-10 h-10 rounded-full bg-slate-800 text-white font-bold flex items-center justify-center cursor-pointer text-xl"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-400">
              {showLoginModal === 'patient'
                ? 'Sila pilih mod pesakit untuk mencuba paparan mesra warga emas (Bahasa Melayu, fon besar, target sentuhan >48px).'
                : 'Pilih mod staf klinikal (Jururawat / Pentadbir) untuk meneruskan sesi pemantauan.'}
            </p>

            <div className="space-y-3 pt-2">
              {showLoginModal === 'patient' ? (
                <button
                  onClick={() => {
                    setShowLoginModal(null);
                    onLoginAsPatient();
                  }}
                  className="w-full min-h-[52px] bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-base rounded-2xl flex items-center justify-center space-x-2 cursor-pointer"
                >
                  <User className="w-5 h-5" />
                  <span>Masuk Sebagai Ahmad bin Ali (P00123)</span>
                </button>
              ) : (
                <>
                  <button
                    onClick={() => {
                      setShowLoginModal(null);
                      onLoginAsNurse();
                    }}
                    className="w-full min-h-[52px] bg-cyan-600 hover:bg-cyan-500 text-white font-black text-base rounded-2xl flex items-center justify-center space-x-2 cursor-pointer"
                  >
                    <Stethoscope className="w-5 h-5" />
                    <span>Masuk Sebagai Sister Siti (Jururawat Klinikal)</span>
                  </button>

                  <button
                    onClick={() => {
                      setShowLoginModal(null);
                      onLoginAsAdmin();
                    }}
                    className="w-full min-h-[52px] bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-base rounded-2xl flex items-center justify-center space-x-2 cursor-pointer"
                  >
                    <ShieldCheck className="w-5 h-5" />
                    <span>Masuk Sebagai Pentadbir (Dr. Azman)</span>
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
