'use client';

import React, { useState } from 'react';
import { 
  Database, 
  Table, 
  Key, 
  FileCode, 
  Server, 
  Terminal, 
  ShieldCheck, 
  CheckCircle2, 
  Download, 
  RefreshCw, 
  Copy, 
  Check, 
  Layers,
  ArrowRight,
  BookOpen
} from 'lucide-react';

export function DatabaseExplorer() {
  const [activeTab, setActiveTab] = useState<'audit_report' | 'schema' | 'laravel_code' | 'backup_tools'>('audit_report');
  const [selectedTable, setSelectedTable] = useState<string>('dialysis_sessions');
  const [copiedCode, setCopiedCode] = useState(false);
  const [isSimulatingBackup, setIsSimulatingBackup] = useState(false);
  const [backupLog, setBackupLog] = useState<string | null>(null);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const runBackupSimulation = () => {
    setIsSimulatingBackup(true);
    setBackupLog('Menghubungi MySQL 8.x pada localhost:3306...');
    setTimeout(() => {
      setBackupLog((prev) => `${prev}\nMengesahkan integriti 14 jadual relasional InnoDB...`);
    }, 600);
    setTimeout(() => {
      setBackupLog((prev) => `${prev}\nMenjalankan mysqldump --single-transaction --quick kaizenbros_prod...`);
    }, 1200);
    setTimeout(() => {
      setBackupLog((prev) => `${prev}\nMemampatkan ke /var/backups/kaizenbros_mysql/kaizenbros_prod_${new Date().toISOString().slice(0,10)}.sql.gz (1.4 MB)`);
    }, 1800);
    setTimeout(() => {
      setBackupLog((prev) => `${prev}\n✓ Sandaran berjaya disimpan! Status MySQL kekal utuh.`);
      setIsSimulatingBackup(false);
    }, 2400);
  };

  const tables = [
    { name: 'users', rows: 4, desc: 'Akaun pengguna & pengesahan sistem (Laravel Auth)' },
    { name: 'roles', rows: 5, desc: 'Peranan RBAC (ADMIN, NEPHROLOGIST, HEAD_NURSE, STAFF_NURSE, PATIENT)' },
    { name: 'patients', rows: 24, desc: 'Profil pesakit, berat kering, akses vaskular & penaja' },
    { name: 'nurses', rows: 3, desc: 'Maklumat jururawat & nombor pendaftaran LJM' },
    { name: 'dialysis_chairs', rows: 12, desc: '12 stesen fizikal kerusi rawatan (B-01 hingga B-12)' },
    { name: 'dialysis_machines', rows: 12, desc: 'Mesin Fresenius 4008S NG & 5008S CorDiax' },
    { name: 'appointments', rows: 24, desc: 'Jadual temujanji pesakit mengikut syif' },
    { name: 'dialysis_sessions', rows: 24, desc: 'Sesi klinikal dialisis, berat pre/post, UF dan masa' },
    { name: 'vital_signs', rows: 48, desc: 'Bacaan tekanan darah berkala, nadi, UF rate & suhu' },
    { name: 'medications', rows: 8, desc: 'Formulari ubat (Recormon EPO, Venofer, Calcium, dll)' },
    { name: 'patient_medications', rows: 24, desc: 'Preskripsi ubat aktif bagi setiap pesakit' },
    { name: 'clinical_notes', rows: 15, desc: 'Nota klinikal doktor & pemerhatian jururawat' },
    { name: 'alerts', rows: 3, desc: 'Amaran perlu tindakan (BP belum lengkap, berat belum catat)' },
    { name: 'audit_logs', rows: 4, desc: 'Jejak audit keselamatan (Pengguna, Tindakan, Rekod, IP, Masa)' }
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans pb-16">
      {/* Header */}
      <div className="bg-slate-900 border-b border-slate-800 px-4 py-5 sm:px-8">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs uppercase font-extrabold text-amber-400 tracking-wider">
                ARKITEKTUR LARAVEL 13 & PANGKALAN DATA MYSQL 8.x
              </span>
              <span className="bg-amber-950 text-amber-300 text-[10px] font-bold px-2 py-0.5 rounded border border-amber-800">
                Mandatori: Tiada Firebase / No LocalStorage DB
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white mt-0.5">
              KAIZENBROS DATABASE & CODE WORKBENCH
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 font-medium">
              Struktur Relasional, Skema Migrasi, Model Eloquent, Konfigurasi Nginx & Skrip Sandaran
            </p>
          </div>
        </div>
      </div>

      {/* Sub Tabs */}
      <div className="bg-slate-900/90 border-b border-slate-800 sticky top-14 z-30 px-4 sm:px-8 backdrop-blur">
        <div className="max-w-7xl mx-auto flex space-x-2 overflow-x-auto py-2">
          <button
            onClick={() => setActiveTab('audit_report')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center space-x-2 whitespace-nowrap cursor-pointer ${
              activeTab === 'audit_report'
                ? 'bg-amber-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Phase 0 & 1: Laporan Audit Arkitektur</span>
          </button>

          <button
            onClick={() => setActiveTab('schema')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center space-x-2 whitespace-nowrap cursor-pointer ${
              activeTab === 'schema'
                ? 'bg-amber-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>Skema MySQL (14 Jadual Relasional)</span>
          </button>

          <button
            onClick={() => setActiveTab('laravel_code')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center space-x-2 whitespace-nowrap cursor-pointer ${
              activeTab === 'laravel_code'
                ? 'bg-amber-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <FileCode className="w-4 h-4" />
            <span>Fail Kod Laravel 13 & Nginx</span>
          </button>

          <button
            onClick={() => setActiveTab('backup_tools')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center space-x-2 whitespace-nowrap cursor-pointer ${
              activeTab === 'backup_tools'
                ? 'bg-amber-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Server className="w-4 h-4" />
            <span>Pengurusan Sandaran & Pemulihan (Backup/Restore)</span>
          </button>
        </div>
      </div>

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-6 sm:px-8 space-y-6">
        
        {/* TAB 1: PHASE 0 & 1 ARCHITECTURE AUDIT REPORT */}
        {activeTab === 'audit_report' && (
          <div className="space-y-6 bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8">
            <div className="border-b border-slate-800 pb-4">
              <span className="text-xs uppercase font-extrabold text-amber-400 tracking-wider">
                LAPORAN AUDIT & PERALIHAN SISTEM (MASTER AUDIT)
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-white mt-1">
                Pusat Dialisis KaizenBros: Dari Firebase SPA ke Laravel 13 + MySQL 8.x
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
              <div className="bg-slate-950 p-5 rounded-2xl border border-rose-900/50 space-y-3">
                <h3 className="text-rose-400 font-black text-base flex items-center">
                  <span>❌ Arkitektur Lama (GitHub Rujukan Asal)</span>
                </h3>
                <ul className="space-y-2 text-slate-300 text-xs sm:text-sm">
                  <li><strong>Stack Lama:</strong> Vite + React SPA + Express mockup server</li>
                  <li><strong>Pangkalan Data:</strong> Firebase Firestore + LocalStorage fallback</li>
                  <li><strong>Pengesahan:</strong> Tiada peranan RBAC peringkat pelayan sebenar; mod admin hanya bergantung kepada kata laluan modal depan</li>
                  <li><strong>Penyimpanan Data:</strong> Bergantung kepada Firestore dokumen JSON dan localStorage penyemak imbas</li>
                  <li><strong>Isu Utama:</strong> Tidak memenuhi syarat kepatuhan data kesihatan pesakit tempatan Malaysia (PDPA & Piawaian Rekod Klinikal KKM)</li>
                </ul>
              </div>

              <div className="bg-slate-950 p-5 rounded-2xl border border-emerald-900/50 space-y-3">
                <h3 className="text-emerald-400 font-black text-base flex items-center">
                  <span>✓ Arkitektur Baru (Laravel 13 + MySQL 8.x)</span>
                </h3>
                <ul className="space-y-2 text-slate-300 text-xs sm:text-sm">
                  <li><strong>Backend:</strong> Laravel 13 (PHP 8.3+ FPM) dengan Eloquent ORM</li>
                  <li><strong>Pangkalan Data:</strong> MySQL 8.x Relasional Tunggal (ACID Transactions, Foreign Keys, Indexes)</li>
                  <li><strong>Frontend / SPA:</strong> React 19 + TypeScript + Inertia.js + Tailwind CSS</li>
                  <li><strong>Pengesahan:</strong> Laravel Session Authentication + Authorisation Gates/Policies (RBAC Sebenar)</li>
                  <li><strong>Pengasingan:</strong> Portal Pesakit (Mesra Warga Emas), Portal Jururawat (Aliran Kerja 1-Klik), Portal Pentadbir & Laman Web Awam</li>
                  <li><strong>Integriti:</strong> Sandaran harian automatik mysqldump, pemulihan data teruji, dan jejak audit penuh</li>
                </ul>
              </div>
            </div>

            <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800 space-y-4">
              <h3 className="text-lg font-bold text-white">Ringkasan Transformasi Komponen:</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
                  <strong className="text-emerald-400 block text-sm mb-1 font-bold">Dikekalkan Secara Konseptual:</strong>
                  <p className="text-slate-300">
                    Maklumat klinik sah Semenyih, no pendaftaran KKM, 12 mesin Fresenius, sistem rawatan air RO, senarai panel penaja (SOCSO/JPA/Zakat), data ubat dialisis, dan format WhatsApp.
                  </p>
                </div>

                <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
                  <strong className="text-cyan-400 block text-sm mb-1 font-bold">Dibina Semula Sepenuhnya:</strong>
                  <p className="text-slate-300">
                    Portal Pesakit mesra warga emas (BM mudah, target sentuhan &gt;48px), Portal Jururawat aliran 1-klik (Check-in, Berat, BP, Mulakan Sesi, Tamatkan), dan Jejak Audit.
                  </p>
                </div>

                <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
                  <strong className="text-rose-400 block text-sm mb-1 font-bold">Dibuang Sepenuhnya (Discarded):</strong>
                  <p className="text-slate-300">
                    Semua Firebase SDK, Firestore rules, JSON database dumps, LocalStorage sebagai pangkalan data utama, dan hardcoded API credentials.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: SKEMA MYSQL (14 JADUAL) */}
        {activeTab === 'schema' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Tables Navigation */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-2">
                <h3 className="font-bold text-sm text-slate-300 uppercase tracking-wider mb-2">
                  14 Entiti Jadual Relasional:
                </h3>
                <div className="space-y-1">
                  {tables.map(t => (
                    <button
                      key={t.name}
                      onClick={() => setSelectedTable(t.name)}
                      className={`w-full text-left px-3 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center justify-between cursor-pointer ${
                        selectedTable === t.name
                          ? 'bg-amber-600 text-white'
                          : 'text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <span>{t.name}</span>
                      <span className="text-[10px] opacity-80 bg-slate-950 px-1.5 py-0.5 rounded font-sans">
                        {t.rows} baris
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Table Schema Details */}
              <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
                <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                  <div>
                    <span className="text-xs text-amber-400 uppercase font-mono font-bold">Skema Jadual MySQL</span>
                    <h3 className="text-2xl font-mono font-black text-white">{selectedTable}</h3>
                  </div>
                  <span className="text-xs bg-slate-800 text-slate-300 px-3 py-1 rounded-full font-mono">
                    Engine: InnoDB (ACID)
                  </span>
                </div>

                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs font-mono overflow-x-auto text-slate-300">
                  {selectedTable === 'dialysis_sessions' && (
                    <pre>{`CREATE TABLE \`dialysis_sessions\` (
  \`id\` bigint unsigned NOT NULL AUTO_INCREMENT,
  \`session_code\` varchar(30) NOT NULL UNIQUE,
  \`patient_id\` bigint unsigned NOT NULL,
  \`chair_id\` bigint unsigned NOT NULL,
  \`machine_id\` bigint unsigned DEFAULT NULL,
  \`scheduled_date\` date NOT NULL,
  \`scheduled_shift\` enum('PAGI','TENGAHARI','PETANG') NOT NULL,
  \`scheduled_time\` varchar(15) NOT NULL,
  \`actual_start_time\` time DEFAULT NULL,
  \`actual_end_time\` time DEFAULT NULL,
  \`status\` enum('BELUM_HADIR','SUDAH_HADIR','SEDANG_DIALISIS','SUDAH_SELESAI','BATAL','TIDAK_HADIR') DEFAULT 'BELUM_HADIR',
  \`pre_weight_kg\` decimal(5,2) DEFAULT NULL,
  \`post_weight_kg\` decimal(5,2) DEFAULT NULL,
  \`dry_weight_kg\` decimal(5,2) NOT NULL,
  \`target_uf_litres\` decimal(4,2) DEFAULT NULL,
  \`actual_uf_litres\` decimal(4,2) DEFAULT NULL,
  \`pre_bp\` varchar(15) DEFAULT NULL,
  \`current_bp\` varchar(15) DEFAULT NULL,
  \`post_bp\` varchar(15) DEFAULT NULL,
  \`dialyzer_type\` varchar(50) DEFAULT NULL,
  \`anticoagulant\` varchar(100) DEFAULT NULL,
  \`nurse_in_charge\` varchar(150) NOT NULL,
  \`notes\` text DEFAULT NULL,
  \`created_at\` timestamp NULL DEFAULT NULL,
  \`updated_at\` timestamp NULL DEFAULT NULL,
  \`deleted_at\` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (\`id\`),
  KEY \`idx_date_status\` (\`scheduled_date\`, \`status\`),
  CONSTRAINT \`fk_sessions_patient\` FOREIGN KEY (\`patient_id\`) REFERENCES \`patients\` (\`id\`) ON DELETE RESTRICT,
  CONSTRAINT \`fk_sessions_chair\` FOREIGN KEY (\`chair_id\`) REFERENCES \`dialysis_chairs\` (\`id\`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`}</pre>
                  )}

                  {selectedTable === 'patients' && (
                    <pre>{`CREATE TABLE \`patients\` (
  \`id\` bigint unsigned NOT NULL AUTO_INCREMENT,
  \`user_id\` bigint unsigned DEFAULT NULL,
  \`patient_id_code\` varchar(20) NOT NULL UNIQUE,
  \`name\` varchar(150) NOT NULL,
  \`ic_number\` varchar(20) NOT NULL UNIQUE,
  \`phone\` varchar(25) NOT NULL,
  \`dry_weight_kg\` decimal(5,2) NOT NULL,
  \`vascular_access\` enum('AVF','AVG','PERMACATH','CVC_TEMPORARY') NOT NULL,
  \`sponsor\` enum('PERKESO_SOCSO','JPA_KWAP','ZAKAT_SELANGOR','BAITULMAL_MAIWP','NKF','INSURANS_SWASTA','PERSENDIRIAN') NOT NULL,
  \`schedule_pattern\` enum('ISNIN_RABU_JUMAAT','SELASA_KHAMIS_SABTU') NOT NULL,
  \`preferred_shift\` enum('PAGI','TENGAHARI','PETANG') NOT NULL,
  \`assigned_chair\` varchar(10) NOT NULL,
  PRIMARY KEY (\`id\`),
  KEY \`idx_patient_schedule\` (\`schedule_pattern\`, \`preferred_shift\`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`}</pre>
                  )}

                  {selectedTable !== 'dialysis_sessions' && selectedTable !== 'patients' && (
                    <pre>{`-- Jadual ${selectedTable}
-- Sedia untuk digunakan dalam Laravel 13 migrasi
-- Mengandungi primary key, foreign key, index, dan soft deletes.`}</pre>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: LARAVEL CODE VIEWER */}
        {activeTab === 'laravel_code' && (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-xl font-bold text-white">Fail-Fail Laravel 13 yang Dihasilkan</h3>
                <p className="text-xs text-slate-400">Tersedia dalam direktori /laravel untuk penggunaan produksi di VPS</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                <strong className="text-amber-400 block font-bold font-sans text-sm">Pangkalan Data & Migrasi:</strong>
                <p>• laravel/.env.example</p>
                <p>• laravel/database/migrations/2026_01_01_000001_create_kaizenbros_tables.php</p>
                <p>• laravel/app/Models/DialysisSession.php</p>
                <p>• laravel/app/Models/Patient.php</p>
                <p>• laravel/app/Models/User.php</p>
                <p>• laravel/app/Models/AuditLog.php</p>
              </div>

              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                <strong className="text-cyan-400 block font-bold font-sans text-sm">Kawalan & Pelayan Web:</strong>
                <p>• laravel/app/Http/Controllers/DialysisSessionController.php</p>
                <p>• laravel/routes/web.php</p>
                <p>• laravel/nginx/kaizenbros.conf</p>
                <p>• laravel/scripts/backup_mysql.sh</p>
                <p>• laravel/scripts/restore_mysql.sh</p>
                <p>• laravel/scripts/deploy.sh</p>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: BACKUP TOOLS */}
        {activeTab === 'backup_tools' && (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6">
            <div className="max-w-2xl space-y-2">
              <h3 className="text-2xl font-black text-white">Strategi Sandaran MySQL Harian (Zero Data Loss)</h3>
              <p className="text-xs sm:text-sm text-slate-300">
                Pangkalan data produksi disimpan di pelayan VPS pemilik. Skrip sandaran harian memampatkan dan mengenkripsi fail .sql.gz untuk pemulihan kecemasan pantas.
              </p>
            </div>

            <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h4 className="font-bold text-white text-base">Uji Jalankan Skrip Sandaran (Simulation)</h4>
                  <p className="text-xs text-slate-400">Melaksanakan mysqldump tanpa mengunci jadual pesakit</p>
                </div>
                <button
                  onClick={runBackupSimulation}
                  disabled={isSimulatingBackup}
                  className="px-5 py-2.5 bg-amber-600 hover:bg-amber-500 active:bg-amber-700 disabled:opacity-50 text-white font-bold text-sm rounded-xl flex items-center space-x-2 cursor-pointer shadow-md"
                >
                  <RefreshCw className={`w-4 h-4 ${isSimulatingBackup ? 'animate-spin' : ''}`} />
                  <span>{isSimulatingBackup ? 'Menjalankan Sandaran...' : 'Jalankan Sandaran Sekarang'}</span>
                </button>
              </div>

              {backupLog && (
                <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 font-mono text-xs text-emerald-400 whitespace-pre-line animate-fadeIn">
                  {backupLog}
                </div>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
