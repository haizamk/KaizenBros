'use client';

import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Users, 
  UserPlus, 
  Shield, 
  Activity, 
  FileText, 
  Settings, 
  Database, 
  Stethoscope, 
  CheckCircle2, 
  Search, 
  Lock, 
  Server,
  Layers,
  Key,
  HardDrive
} from 'lucide-react';
import { User, AuditLog, DialysisChair, DialysisMachine, Patient, Nurse } from '@/types';
import { INITIAL_CHAIRS, INITIAL_MACHINES, INITIAL_PATIENTS, INITIAL_NURSES, INITIAL_AUDIT_LOGS, VERIFIED_CENTRE_INFO } from '@/lib/mock-data';

interface AdminPortalProps {
  auditLogs?: AuditLog[];
}

export function AdminPortal({ auditLogs = INITIAL_AUDIT_LOGS }: AdminPortalProps) {
  const [activeTab, setActiveTab] = useState<'ringkasan' | 'pengguna' | 'pesakit' | 'jururawat' | 'stesen' | 'audit' | 'tetapan'>('ringkasan');
  const [searchLog, setSearchLog] = useState('');

  const [usersList, setUsersList] = useState<User[]>([
    {
      id: 1,
      name: 'Dr. Azman bin Khairuddin',
      email: 'dr.azman@kaizenbrosdialysis.com.my',
      role: 'NEPHROLOGIST',
      phone: '019-3389922',
      ic_number: '740518-10-5891',
      is_active: true,
      last_login_at: '2026-09-25 08:30:00',
      created_at: '2021-01-15'
    },
    {
      id: 2,
      name: 'Sister Siti Fatimah binti Rahman',
      email: 'siti.fatimah@kaizenbrosdialysis.com.my',
      role: 'HEAD_NURSE',
      phone: '012-3456789',
      ic_number: '820412-10-5322',
      is_active: true,
      last_login_at: '2026-09-25 06:00:00',
      created_at: '2021-02-01'
    },
    {
      id: 3,
      name: 'Staff Nurse Faridah binti Kassim',
      email: 'faridah@kaizenbrosdialysis.com.my',
      role: 'STAFF_NURSE',
      phone: '013-8899123',
      ic_number: '900822-10-5014',
      is_active: true,
      last_login_at: '2026-09-25 13:45:00',
      created_at: '2022-03-10'
    },
    {
      id: 4,
      name: 'Ahmad bin Ali',
      email: 'ahmad.ali@gmail.com',
      role: 'PATIENT',
      phone: '012-9876543',
      ic_number: '580412-10-5541',
      is_active: true,
      last_login_at: '2026-09-25 13:50:00',
      created_at: '2023-04-10'
    }
  ]);

  const filteredLogs = auditLogs.filter(log => 
    log.user_name.toLowerCase().includes(searchLog.toLowerCase()) ||
    log.action.toLowerCase().includes(searchLog.toLowerCase()) ||
    log.details.toLowerCase().includes(searchLog.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans pb-16">
      {/* Top Banner */}
      <div className="bg-slate-900 border-b border-slate-800 px-4 py-5 sm:px-8">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs uppercase font-extrabold text-indigo-400 tracking-wider">
                PORTAL PENTADBIRAN SISTEM & KAWALAN KLINIKAL
              </span>
              <span className="bg-indigo-950 text-indigo-300 text-[10px] font-bold px-2 py-0.5 rounded border border-indigo-800">
                Akses Pentadbir Aras Tinggi
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white mt-0.5">
              PENTADBIR PUSAT DIALISIS KAIZENBROS
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 font-medium">
              Pengurusan Pengguna, RBAC, Stesen Mesin Dialisis, Keselamatan & Log Audit
            </p>
          </div>
        </div>
      </div>

      {/* Admin Navigation */}
      <div className="bg-slate-900/90 border-b border-slate-800 sticky top-14 z-30 px-4 sm:px-8 backdrop-blur">
        <div className="max-w-7xl mx-auto flex space-x-2 overflow-x-auto py-2">
          {[
            { id: 'ringkasan', label: 'Ringkasan', icon: Activity },
            { id: 'pengguna', label: 'Pengguna & Peranan (RBAC)', icon: Shield },
            { id: 'pesakit', label: 'Pesakit', icon: Users },
            { id: 'jururawat', label: 'Jururawat', icon: Stethoscope },
            { id: 'stesen', label: 'Stesen & Mesin Fresenius', icon: Layers },
            { id: 'audit', label: 'Log Audit (Audit Trail)', icon: FileText },
            { id: 'tetapan', label: 'Tetapan Pusat', icon: Settings }
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center space-x-2 whitespace-nowrap cursor-pointer ${
                  activeTab === tab.id
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Admin Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-6 sm:px-8 space-y-6">
        
        {/* TAB 1: RINGKASAN */}
        {activeTab === 'ringkasan' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl">
                <span className="text-xs font-semibold text-slate-400 uppercase">Jumlah Akaun Pengguna</span>
                <div className="text-3xl font-black text-white mt-1">{usersList.length + 20}</div>
                <span className="text-xs text-indigo-400">4 Pentadbir / Jururawat, 20 Pesakit</span>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl">
                <span className="text-xs font-semibold text-slate-400 uppercase">Stesen & Mesin Aktif</span>
                <div className="text-3xl font-black text-cyan-400 mt-1">12 / 12</div>
                <span className="text-xs text-slate-400">Fresenius 4008S & 5008S CorDiax</span>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl">
                <span className="text-xs font-semibold text-slate-400 uppercase">Status Pangkalan Data</span>
                <div className="text-3xl font-black text-emerald-400 mt-1">MySQL 8.x</div>
                <span className="text-xs text-emerald-500">14 Entiti Relasional Berintegriti</span>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl">
                <span className="text-xs font-semibold text-slate-400 uppercase">Tindakan Diaudit</span>
                <div className="text-3xl font-black text-amber-400 mt-1">{auditLogs.length}</div>
                <span className="text-xs text-slate-400">ACID Log Transaksi Penuh</span>
              </div>
            </div>

            {/* Quick Audit Log Overview */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
              <h3 className="text-lg font-black text-white flex items-center">
                <FileText className="w-5 h-5 mr-2 text-indigo-400" />
                Aktiviti Log Audit Terkini
              </h3>
              <div className="divide-y divide-slate-800 text-sm">
                {auditLogs.slice(0, 4).map(l => (
                  <div key={l.id} className="py-2.5 flex justify-between items-center">
                    <div>
                      <span className="font-bold text-white mr-2">{l.user_name} ({l.user_role})</span>
                      <span className="text-xs text-indigo-300 font-mono bg-indigo-950 px-2 py-0.5 rounded border border-indigo-800">
                        {l.action}
                      </span>
                      <p className="text-xs text-slate-400 mt-0.5">{l.details}</p>
                    </div>
                    <span className="text-xs text-slate-500 font-mono">{l.created_at}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: PENGGUNA & RBAC */}
        {activeTab === 'pengguna' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-black text-white">Pengurusan Pengguna & Peranan (RBAC)</h2>
                <p className="text-xs text-slate-400">Kawalan akses ketat mengikut peranan berasaskan Laravel Authorisation Gate & Policy</p>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
              <table className="w-full text-left text-sm text-slate-300">
                <thead className="bg-slate-950 text-slate-400 text-xs uppercase border-b border-slate-800">
                  <tr>
                    <th className="px-5 py-3.5">Nama & Emel</th>
                    <th className="px-5 py-3.5">Peranan (Role)</th>
                    <th className="px-5 py-3.5">No. Telefon</th>
                    <th className="px-5 py-3.5">Log Masuk Terakhir</th>
                    <th className="px-5 py-3.5">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {usersList.map((u) => (
                    <tr key={u.id} className="hover:bg-slate-850/50">
                      <td className="px-5 py-4">
                        <strong className="text-white block font-bold">{u.name}</strong>
                        <span className="text-xs text-slate-400">{u.email}</span>
                      </td>
                      <td className="px-5 py-4">
                        <span className={`text-xs font-bold px-2.5 py-1 rounded border ${
                          u.role === 'ADMIN' ? 'bg-rose-950 text-rose-300 border-rose-800' :
                          u.role === 'NEPHROLOGIST' ? 'bg-indigo-950 text-indigo-300 border-indigo-800' :
                          u.role === 'HEAD_NURSE' || u.role === 'STAFF_NURSE' ? 'bg-cyan-950 text-cyan-300 border-cyan-800' :
                          'bg-emerald-950 text-emerald-300 border-emerald-800'
                        }`}>
                          {u.role}
                        </span>
                      </td>
                      <td className="px-5 py-4 text-xs font-mono">{u.phone}</td>
                      <td className="px-5 py-4 text-xs text-slate-400">{u.last_login_at || 'Baru'}</td>
                      <td className="px-5 py-4">
                        <span className="text-xs font-bold text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded">
                          Aktif
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 5: STESEN & MESIN FRESENIUS */}
        {activeTab === 'stesen' && (
          <div className="space-y-4">
            <h2 className="text-2xl font-black text-white">12 Stesen & Mesin Hemodialisis Fresenius</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {INITIAL_MACHINES.map((m) => (
                <div key={m.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-2xl font-black text-cyan-400">{m.chair_number}</span>
                    <span className="text-xs bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded font-bold">
                      {m.status}
                    </span>
                  </div>
                  <h4 className="font-bold text-white text-base">{m.brand_model}</h4>
                  <p className="text-xs font-mono text-slate-400">S/N: {m.serial_number}</p>
                  <div className="pt-2 border-t border-slate-800 text-xs flex justify-between text-slate-400">
                    <span>Servis Terakhir: {m.last_service_date}</span>
                    <span className="text-cyan-400 font-semibold">{m.online_hdf_capable ? 'Online HDF Ready' : 'Standard HD'}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 6: AUDIT LOGS */}
        {activeTab === 'audit' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div>
                <h2 className="text-2xl font-black text-white">Log Audit Keselamatan & Klinikal</h2>
                <p className="text-xs text-slate-400">Mandatori: Merakam setiap pengguna, tindakan, rekod pesakit, IP dan cap masa tanpa kata laluan</p>
              </div>

              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  placeholder="Cari log audit..."
                  value={searchLog}
                  onChange={(e) => setSearchLog(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white"
                />
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-950 text-slate-400 uppercase border-b border-slate-800">
                    <tr>
                      <th className="px-4 py-3">Tarikh / Masa</th>
                      <th className="px-4 py-3">Pengguna</th>
                      <th className="px-4 py-3">Tindakan</th>
                      <th className="px-4 py-3">Butiran Tindakan</th>
                      <th className="px-4 py-3">Alamat IP</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 font-mono">
                    {filteredLogs.map((log) => (
                      <tr key={log.id} className="hover:bg-slate-850/50">
                        <td className="px-4 py-3 text-slate-400 whitespace-nowrap">{log.created_at}</td>
                        <td className="px-4 py-3 text-white font-bold">{log.user_name} ({log.user_role})</td>
                        <td className="px-4 py-3">
                          <span className="bg-indigo-950 text-indigo-300 px-2 py-0.5 rounded border border-indigo-800 font-semibold">
                            {log.action}
                          </span>
                        </td>
                        <td className="px-4 py-3 font-sans text-slate-200">{log.details}</td>
                        <td className="px-4 py-3 text-slate-500">{log.ip_address}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 7: TETAPAN PUSAT */}
        {activeTab === 'tetapan' && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4 max-w-2xl text-sm">
            <h2 className="text-2xl font-black text-white">Profil Berdaftar Pusat Dialisis</h2>
            <div className="space-y-3">
              <div>
                <span className="text-xs text-slate-400 block">Nama Pusat:</span>
                <strong className="text-white text-base">{VERIFIED_CENTRE_INFO.name}</strong>
              </div>
              <div>
                <span className="text-xs text-slate-400 block">No. Pendaftaran KKM:</span>
                <strong className="text-emerald-400">{VERIFIED_CENTRE_INFO.kkm_license}</strong>
              </div>
              <div>
                <span className="text-xs text-slate-400 block">Alamat Penuh:</span>
                <p className="text-slate-300">{VERIFIED_CENTRE_INFO.address}</p>
              </div>
              <div className="grid grid-cols-2 gap-3 pt-2">
                <div>
                  <span className="text-xs text-slate-400 block">Telefon Utama:</span>
                  <p className="font-mono text-white">{VERIFIED_CENTRE_INFO.phone_main}</p>
                </div>
                <div>
                  <span className="text-xs text-slate-400 block">Talian Kecemasan 24 Jam:</span>
                  <p className="font-mono text-rose-400 font-bold">{VERIFIED_CENTRE_INFO.hotline_24h}</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
